# models/model_comparison.py
"""
模型比较工具，用于分析不同模型的参数量和计算复杂度。
"""
import torch
import time
import numpy as np
from typing import Dict, List, Tuple

# 导入所有模型
try:
    from models.aer_unet import get_aer_unet_model
    print("成功导入 AER U-Net 模型")
except Exception as e:
    print(f"导入 AER U-Net 模型时出错: {e}")

try:
    from models.lightweight_unet import get_lightweight_unet_model
    print("成功导入 Lightweight U-Net 模型")
except Exception as e:
    print(f"导入 Lightweight U-Net 模型时出错: {e}")

def count_parameters(model: torch.nn.Module) -> int:
    """计算模型参数量"""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def count_flops(model: torch.nn.Module, input_shape: Tuple[int, int, int, int]) -> int:
    """
    估算模型的浮点运算次数(FLOPs)
    这是一个简化的估算，实际FLOPs可能有所不同
    
    Args:
        model: 要评估的模型
        input_shape: 输入张量形状 (batch_size, channels, height, width)
    
    Returns:
        估算的FLOPs
    """
    model.eval()
    
    def flop_count_hook(module, input, output):
        if isinstance(module, torch.nn.Conv2d):
            # 计算卷积层的FLOPs
            input_channels = input[0].size(1)
            output_channels = output.size(1)
            kernel_h, kernel_w = module.kernel_size
            output_h, output_w = output.size(2), output.size(3)
            
            # 乘加运算次数
            flops = kernel_h * kernel_w * input_channels * output_channels * output_h * output_w
            module._flops = flops
            
        elif isinstance(module, torch.nn.Linear):
            # 计算全连接层的FLOPs
            input_features = input[0].size(1)
            output_features = output.size(1)
            
            # 乘加运算次数
            flops = input_features * output_features
            module._flops = flops
    
    # 注册钩子
    hooks = []
    for module in model.modules():
        if isinstance(module, (torch.nn.Conv2d, torch.nn.Linear)):
            hook = module.register_forward_hook(flop_count_hook)
            hooks.append(hook)
    
    # 前向传播
    device = next(model.parameters()).device
    x = torch.randn(input_shape, device=device)
    with torch.no_grad():
        model(x)
    
    # 计算总FLOPs
    total_flops = 0
    for module in model.modules():
        if hasattr(module, '_flops'):
            total_flops += module._flops
            delattr(module, '_flops')
    
    # 移除钩子
    for hook in hooks:
        hook.remove()
    
    return total_flops

def measure_inference_time(model: torch.nn.Module, input_shape: Tuple[int, int, int, int], 
                          device: str = 'cuda', warmup: int = 10, repeats: int = 50) -> Dict[str, float]:
    """
    测量模型推理时间
    
    Args:
        model: 要评估的模型
        input_shape: 输入张量形状
        device: 使用的设备
        warmup: 预热次数
        repeats: 重复测量次数
    
    Returns:
        包含平均推理时间和标准差的字典
    """
    model.eval()
    model.to(device)
    
    # 创建输入数据
    x = torch.randn(input_shape, device=device)
    
    # 预热
    with torch.no_grad():
        for _ in range(warmup):
            _ = model(x)
    
    # 同步确保所有操作完成
    if device == 'cuda':
        torch.cuda.synchronize()
    
    # 测量推理时间
    times = []
    with torch.no_grad():
        for _ in range(repeats):
            start_time = time.time()
            _ = model(x)
            if device == 'cuda':
                torch.cuda.synchronize()
            end_time = time.time()
            times.append(end_time - start_time)
    
    return {
        'mean_time': np.mean(times) * 1000,  # 转换为毫秒
        'std_time': np.std(times) * 1000,    # 转换为毫秒
        'min_time': np.min(times) * 1000,    # 转换为毫秒
        'max_time': np.max(times) * 1000     # 转换为毫秒
    }

def compare_models(input_shape: Tuple[int, int, int, int] = (1, 6, 256, 256), 
                  device: str = 'cuda' if torch.cuda.is_available() else 'cpu') -> Dict:
    """
    比较不同模型的性能指标
    
    Args:
        input_shape: 输入张量形状
        device: 使用的设备
    
    Returns:
        包含各模型性能指标的字典
    """
    results = {}
    
    # 定义要比较的模型
    models = {
        'AER U-Net': lambda: get_aer_unet_model(n_channels=input_shape[1]),
        'Lightweight U-Net': lambda: get_lightweight_unet_model(n_channels=input_shape[1])
    }
    
    # 比较每个模型
    for name, model_fn in models.items():
        print(f"\n正在评估 {name}...")
        
        try:
            # 创建模型
            model = model_fn()
            
            # 计算参数量
            param_count = count_parameters(model)
            
            # 计算FLOPs
            flops = count_flops(model, input_shape)
            
            # 测量推理时间
            inference_time = measure_inference_time(model, input_shape, device)
            
            # 保存结果
            results[name] = {
                'parameters': param_count,
                'flops': flops,
                'inference_time_ms': inference_time['mean_time'],
                'inference_time_std': inference_time['std_time'],
                'min_inference_time_ms': inference_time['min_time'],
                'max_inference_time_ms': inference_time['max_time']
            }
            
            print(f"  参数量: {param_count:,}")
            print(f"  FLOPs: {flops:,}")
            print(f"  平均推理时间: {inference_time['mean_time']:.2f} ± {inference_time['std_time']:.2f} ms")
            
        except Exception as e:
            print(f"  评估 {name} 时出错: {str(e)}")
            results[name] = {
                'error': str(e)
            }
    
    return results

def print_comparison_table(results: Dict) -> None:
    """打印模型比较表格"""
    print("\n" + "="*80)
    print("模型性能比较")
    print("="*80)
    
    # 表头
    print(f"{'模型名称':<20} {'参数量':<15} {'FLOPs':<15} {'推理时间(ms)':<20}")
    print("-" * 80)
    
    # 打印每个模型的结果
    for name, metrics in results.items():
        if 'error' in metrics:
            print(f"{name:<20} {'错误':<15} {'错误':<15} {metrics['error']:<20}")
        else:
            params = f"{metrics['parameters']:,}"
            flops = f"{metrics['flops']:,}"
            time_str = f"{metrics['inference_time_ms']:.2f} ± {metrics['inference_time_std']:.2f}"
            print(f"{name:<20} {params:<15} {flops:<15} {time_str:<20}")
    
    print("="*80)

def calculate_efficiency_score(results: Dict) -> Dict[str, float]:
    """
    计算模型的效率分数（考虑参数量、FLOPs和推理时间）
    分数越低表示效率越高
    
    Args:
        results: 模型比较结果
    
    Returns:
        各模型的效率分数
    """
    # 提取有效的结果
    valid_results = {name: metrics for name, metrics in results.items() if 'error' not in metrics}
    
    if not valid_results:
        return {}
    
    # 归一化指标
    max_params = max(metrics['parameters'] for metrics in valid_results.values())
    max_flops = max(metrics['flops'] for metrics in valid_results.values())
    max_time = max(metrics['inference_time_ms'] for metrics in valid_results.values())
    
    # 计算效率分数（加权平均）
    efficiency_scores = {}
    for name, metrics in valid_results.items():
        # 归一化到[0, 1]范围
        norm_params = metrics['parameters'] / max_params
        norm_flops = metrics['flops'] / max_flops
        norm_time = metrics['inference_time_ms'] / max_time
        
        # 计算加权平均分数（权重可根据需求调整）
        efficiency_score = 0.3 * norm_params + 0.3 * norm_flops + 0.4 * norm_time
        efficiency_scores[name] = efficiency_score
    
    return efficiency_scores

if __name__ == "__main__":
    # 比较模型
    results = compare_models()
    
    # 打印比较表格
    print_comparison_table(results)
    
    # 计算并打印效率分数
    efficiency_scores = calculate_efficiency_score(results)
    if efficiency_scores:
        print("\n效率分数（越低越好）:")
        for name, score in sorted(efficiency_scores.items(), key=lambda x: x[1]):
            print(f"  {name}: {score:.4f}")